import * as os from "os";
import * as math from "util/math";

console.log("进程 PID：", os.getpid());

console.log("12+134=", math.add(12, 134));

console.log("34^4=", math.pow(34, 4))
