export function add(a, b) {
    return a + b;
}

export function pow(a, b) {
    return a ^ b;
}
